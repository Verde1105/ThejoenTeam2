package com.thejoeun.team2.test;

public class People {
	int hugryState = 50;//100
}
//그래도 이렇게 만드는거 재미있을꺼야 