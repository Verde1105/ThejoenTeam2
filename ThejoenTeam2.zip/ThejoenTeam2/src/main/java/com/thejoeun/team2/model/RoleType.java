package com.thejoeun.team2.model;


//이넘은 넣을 수 있는 데이터 값을 강제할수있다.
//도메인으로 많이 사용.
public enum RoleType {
	USER,ADMIN
}
