package com.thejoeun.team2.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.thejoeun.team2.model.Covid19Data;

public interface Covid19DataRepository extends JpaRepository<Covid19Data, Long>{

}
